CARA MENJALANKAN:
1. Extract ZIP.
2. Buka index.html di browser.
3. Untuk musik, masukkan file MP3 ke assets/music/ dengan nama music.mp3.
4. Edit teks di index.html jika ingin mengganti ucapan.
5. Edit warna/tampilan di style.css.
