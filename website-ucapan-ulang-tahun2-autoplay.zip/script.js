const music = document.getElementById("bgMusic");
const musicBtn = document.getElementById("musicBtn");

let musicStarted = false;

// Coba autoplay saat website dibuka.
// Jika browser memblokir autoplay, musik akan mulai pada interaksi pertama.
async function startMusic() {
  if (musicStarted || !music.paused) return;

  try {
    await music.play();
    musicStarted = true;
    musicBtn.classList.add("playing");
    musicBtn.textContent = "❚❚";
  } catch (error) {
    // Autoplay diblokir browser. Tunggu interaksi pengguna.
  }
}

// Coba langsung saat halaman selesai dimuat.
window.addEventListener("load", startMusic);

// Fallback: mulai musik setelah interaksi pertama.
["click", "touchstart", "scroll", "keydown"].forEach((eventName) => {
  document.addEventListener(eventName, startMusic, { once: true });
});

// Tombol musik manual.
musicBtn.addEventListener("click", async (event) => {
  event.stopPropagation();

  if (music.paused) {
    try {
      await music.play();
      musicStarted = true;
      musicBtn.classList.add("playing");
      musicBtn.textContent = "❚❚";
    } catch (error) {
      console.log("Musik belum bisa diputar.", error);
    }
  } else {
    music.pause();
    musicStarted = false;
    musicBtn.classList.remove("playing");
    musicBtn.textContent = "♫";
  }
});

// Animasi elemen ketika masuk viewport.
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("show");
      }
    });
  },
  {
    threshold: 0.15
  }
);

document.querySelectorAll(".reveal").forEach((element) => {
  observer.observe(element);
});
